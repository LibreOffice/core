Writer2LaTeX version 0.5.0.2
============================

This is the distribution of Writer2LaTeX version 0.5.0.2

Latest version can be found at the web site
  http://www.hj-gym.dk/~hj/writer2latex
  
You can read about installation and usage of Writer2LaTeX
in the user guide, which is included in the
directory doc.
  
Bugs and feature requests should be reported to
  henrikjust (at) openoffice.org
  

September 2008
Henrik Just
