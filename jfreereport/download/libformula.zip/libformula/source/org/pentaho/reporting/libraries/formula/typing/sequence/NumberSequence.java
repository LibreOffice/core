package org.pentaho.reporting.libraries.formula.typing.sequence;

import org.pentaho.reporting.libraries.formula.typing.Sequence;
import org.pentaho.reporting.libraries.formula.EvaluationException;

/**
 * Todo: Document Me
 *
 * @author Thomas Morgner
 */
public interface NumberSequence extends Sequence
{
  Number nextNumber() throws EvaluationException;
}
