/**
 * ===========================================
 * LibFonts : a free Java font reading library
 * ===========================================
 *
 * Project Info:  http://reporting.pentaho.org/libfonts/
 *
 * (C) Copyright 2006-2007, by Pentaho Corporation and Contributors.
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc.
 * in the United States and other countries.]
 *
 * ------------
 * $Id: MonospaceFontMetrics.java 3523 2007-10-16 11:03:09Z tmorgner $
 * ------------
 * (C) Copyright 2006-2007, by Pentaho Corporation.
 */

package org.jfree.fonts.monospace;

import org.jfree.fonts.LibFontsDefaults;
import org.jfree.fonts.registry.BaselineInfo;
import org.jfree.fonts.registry.FontMetrics;

/**
 * Creation-Date: 13.05.2007, 13:14:25
 *
 * @author Thomas Morgner
 */
public class MonospaceFontMetrics implements FontMetrics
{
  private static final long MICRO_DOTS_PER_INCH = 72000;
  private long charHeight;
  private long charWidth;

  public MonospaceFontMetrics(final float cpi, final float lpi)
  {
    charHeight = (long)(MICRO_DOTS_PER_INCH / lpi);
    charWidth = (long)(MICRO_DOTS_PER_INCH / cpi);
  }

  /**
   * From the baseline to the
   *
   * @return
   */
  public long getAscent()
  {
    return (long) (LibFontsDefaults.DEFAULT_ASCENT_SIZE * charHeight);
  }

  public long getDescent()
  {
    return (long) (LibFontsDefaults.DEFAULT_DESCENT_SIZE * charHeight);
  }

  public long getLeading()
  {
    return 0;
  }

  /**
   * The height of the lowercase 'x'. This is used as hint, which size the lowercase characters will have.
   *
   * @return
   */
  public long getXHeight()
  {
    return (long) (LibFontsDefaults.DEFAULT_XHEIGHT_SIZE * charHeight);
  }

  public long getOverlinePosition()
  {
    return getLeading() - Math.max (1000, charHeight / 20);
  }

  public long getUnderlinePosition()
  {
    return getAscent() + Math.max (1000, charHeight / 20);
  }

  public long getStrikeThroughPosition()
  {
    return (long) (LibFontsDefaults.DEFAULT_STRIKETHROUGH_POSITION * getXHeight());
  }

  public long getMaxAscent()
  {
    return getAscent();
  }

  public long getMaxDescent()
  {
    return getDescent();
  }

  public long getMaxHeight()
  {
    return charHeight;
  }

  public long getMaxCharAdvance()
  {
    return charWidth;
  }

  public long getCharWidth(final int codePoint)
  {
    return charWidth;
  }

  public long getKerning(final int previous, final int codePoint)
  {
    return 0;
  }

  public long getItalicAngle()
  {
    return 0;
  }

  /**
   * Baselines are defined for scripts, not glyphs. A glyph carries script information most of the time (unless it is a
   * neutral characters or just weird).
   *
   * @param codePoint
   * @return
   */
  public BaselineInfo getBaselines(final int codePoint, BaselineInfo info)
  {
    if (info == null)
    {
      info = new BaselineInfo();
    }


    info.setBaseline(BaselineInfo.HANGING, 0);
    info.setBaseline(BaselineInfo.MATHEMATICAL, charHeight / 2);
    info.setBaseline(BaselineInfo.CENTRAL, charHeight / 2);
    info.setBaseline(BaselineInfo.MIDDLE, charHeight / 2);
    info.setBaseline(BaselineInfo.ALPHABETIC, getMaxAscent());
    info.setBaseline(BaselineInfo.IDEOGRAPHIC, getMaxHeight());
    return info;
  }
}
