The files contained in this directory have been taken from:

http://www.unicode.org/Public

They are used to generate the binary encoding maps. They are not required
at runtime.
