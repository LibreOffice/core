/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2008 - 2009 Pentaho Corperation and Contributors.  All rights reserved.
 */

package org.pentaho.reporting.libraries.formatting;

import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.ResourceBundle;

import org.pentaho.reporting.libraries.base.util.ObjectUtilities;

/**
 * A wrapper around the java.text.DecimalFormat class. This wrapper limits the possible interactions with
 * the wrapped format class and therefore eliminates the need to clone the choice format whenever the
 * wrapper is cloned.
 *
 * @author Thomas Morgner
 */
public class FastDecimalFormat implements FastFormat
{
  /** A format-type constant indicating the system's default number format. */
  public static final int TYPE_DEFAULT = 0;
  /** A format-type constant indicating the system's default integer format. */
  public static final int TYPE_INTEGER = 1;
  /** A format-type constant indicating the system's default currency format. */
  public static final int TYPE_CURRENCY = 2;
  /** A format-type constant indicating the system's default percentage format. */ 
  public static final int TYPE_PERCENT = 3;

  private Locale locale;
  private DecimalFormat decimalFormat;
  private String pattern;

  /**
   * Creates a new decimal-format for the given pattern.
   *
   * @param pattern the pattern string.
   */
  public FastDecimalFormat(final String pattern)
  {
    this(pattern, Locale.getDefault());
  }

  /**
   * Creates a new decimal-format for the given pattern and locale.
   *
   * @param pattern the pattern string.
   * @param locale  the locale.
   */
  public FastDecimalFormat(final String pattern, final Locale locale)
  {
    if (pattern == null)
    {
      throw new NullPointerException();
    }
    if (locale == null)
    {
      throw new NullPointerException();
    }
    this.pattern = pattern;
    this.locale = locale;
    this.decimalFormat = new DecimalFormat(pattern, new DecimalFormatSymbols(locale));
  }

  /**
   * Creates a new number-format for the given type using the standard JDK methods.
   *
   * @param type the type.
   * @param locale the locale for which the format shoudl be created.
   * @return the number format or null, if there was an error while creating the format.
   */
  private NumberFormat createFormat(final int type, final Locale locale)
  {
    final String methodName;
    switch (type)
    {
      case TYPE_INTEGER:
      {
        methodName = "getIntegerInstance";
        break;
      }
      case TYPE_PERCENT:
      {
        return NumberFormat.getPercentInstance(locale);
      }
      case TYPE_CURRENCY:
      {
        return NumberFormat.getCurrencyInstance(locale);
      }
      default:
      {
        return NumberFormat.getInstance(locale);
      }
    }

    if (ObjectUtilities.isJDK14() == false)
    {
      return null;
    }

    try
    {
      final Method method = NumberFormat.class.getMethod(methodName, new Class[]{Locale.class});
      return (NumberFormat) method.invoke(null, new Object[]{locale});
    }
    catch (Exception e)
    {
      // DebugLog.log("Failed to create number-format", e);
      return null;
    }
  }

  /**
   * Creates a new date-format for the given default date and time style.
   *
   * @param type   the number-style, one of TYPE_INTEGER, TYPE_PERCENT, TYPE_CURRENCY or TYPE_DEFAULT.
   * @param locale the locale.
   * @throws IllegalArgumentException if both date and time-style are set to -1.
   */
  public FastDecimalFormat(final int type, final Locale locale)
  {
    if (locale == null)
    {
      throw new NullPointerException();
    }

    final NumberFormat rawFormat = createFormat(type, locale);
    if (rawFormat instanceof DecimalFormat)
    {
      this.decimalFormat = (DecimalFormat) rawFormat;
      this.pattern = decimalFormat.toPattern();
      this.locale = locale;
    }
    else
    {
      final ResourceBundle patterns = ResourceBundle.getBundle
          ("org.pentaho.reporting.libraries.formatting.format-patterns");

      switch (type)
      {
        case TYPE_INTEGER:
        {
          pattern = patterns.getString("format.integer");
          break;
        }
        case TYPE_PERCENT:
        {
          pattern = patterns.getString("format.percentage");
          break;
        }
        case TYPE_CURRENCY:
        {
          pattern = patterns.getString("format.currency");
          break;
        }
        default:
        {
          pattern = patterns.getString("format.number");
        }
      }

      this.locale = locale;
      this.decimalFormat = new DecimalFormat(pattern, new DecimalFormatSymbols(locale));
    }
  }

  /**
   * Updates the locale of  the choice format. This has no impact on the result of the choice-format computation.
   *
   * @param locale the locale, never null.
   */
  public void setLocale(final Locale locale)
  {
    if (locale == null)
    {
      throw new NullPointerException();
    }
    if (this.locale.equals(locale))
    {
      return;
    }
    this.locale = locale;
    this.decimalFormat = (DecimalFormat) decimalFormat.clone();
    this.decimalFormat.setDecimalFormatSymbols(new DecimalFormatSymbols(locale));
  }

  /**
   * Returns the current locale of the formatter.
   *
   * @return the current locale, never null.
   */
  public Locale getLocale()
  {
    return locale;
  }

  /**
   * Returns the currently active pattern.
   *
   * @return the locale.
   */
  public String getPattern()
  {
    return pattern;
  }

  /**
   * Formats the given object in a formatter-specific way.
   *
   * @param parameters the parameters for the formatting.
   * @return the formatted string.
   */
  public String format(final Object parameters)
  {
    if (parameters == null)
    {
      throw new NullPointerException();
    }
    return decimalFormat.format(parameters);
  }

  /**
   * Clones the formatter.
   *
   * @return the clone.
   * @throws CloneNotSupportedException if cloning failed.
   */
  public Object clone() throws CloneNotSupportedException
  {
    return super.clone();
  }
}
