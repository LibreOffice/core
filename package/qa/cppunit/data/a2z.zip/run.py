#!/usr/bin/env python3

for c in range(ord('a'), ord('z')+1):
    s = chr(c)
    with open("{}.txt".format(s), "wb") as f:
        bs = bytes(s*1048576, "utf-8")
        f.write(bs)

