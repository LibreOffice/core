# libreoffice-style-elementary
elementary icons for LibreOffice

This icon theme for LibreOffice is based on the "human" icon theme developed for Ubuntu as well as the "elementary" icon theme.
This icon theme can be redistributed and/or modified under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
