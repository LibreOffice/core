// If using XMultiServiceFactory need to uncomment import directive below:
//import com.sun.star.lang.XMultiServiceFactory;

// If using XDesktop need to uncomment import directive below:
//import com.sun.star.frame.XDesktop;

// If using XComponent need to uncomment import directive below:
//import com.sun.star.lang.XComponent;
import drafts.com.sun.star.script.framework.XScriptContext;
import java.io.*;
import java.util.Calendar;

public class Empty {

  public void hehe(XScriptContext xSc) {
      
      /* Methods available from XScriptContext: 
            xSc.getDocument() returns XModel
            xSc.getDesktop() returns XDesktop
            xSc.getMultiComponentFactory() returns XMultiComponentFactory
        */
        
        // Uncomment to get the current document as a component
        // XComponent xcomponent = xSc.getDocument();
        try {
            PrintStream out =
                new PrintStream(new FileOutputStream("/tmp/test.out"));
            out.println("ran hehe at: " + Calendar.getInstance().getTime());
        }
        catch (Exception e) {
            System.err.println("couldn't get stream");
        }
  }

}
