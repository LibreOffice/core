import com.sun.star.uno.XComponentContext;
import com.sun.star.frame.XDesktop;
import com.sun.star.frame.XModel;
import drafts.com.sun.star.script.framework.XScriptContext;

public class TestXScriptContext {
    public void test(XScriptContext xSc) {
        XComponentContext msf = xSc.getComponentContext();
        XDesktop desktop = xSc.getDesktop();
        XModel model = xSc.getDocument();
    }
}
