using __STL_NEW_IO_NAMESPACE::basic_streambuf;
using __STL_NEW_IO_NAMESPACE::streambuf;
#ifndef __STL_NO_WIDE_STREAMS
using __STL_NEW_IO_NAMESPACE::wstreambuf;
# endif
