using __STL_NEW_IO_NAMESPACE::setiosflags;
using __STL_NEW_IO_NAMESPACE::resetiosflags;
using __STL_NEW_IO_NAMESPACE::setbase;
using __STL_NEW_IO_NAMESPACE::setfill;
using __STL_NEW_IO_NAMESPACE::setprecision;
using __STL_NEW_IO_NAMESPACE::setw;
