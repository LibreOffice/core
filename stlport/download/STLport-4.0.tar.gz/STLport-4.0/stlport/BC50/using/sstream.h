using __STL_NEW_IO_NAMESPACE::basic_stringbuf;
using __STL_NEW_IO_NAMESPACE::stringbuf;

using __STL_NEW_IO_NAMESPACE::basic_istringstream;
using __STL_NEW_IO_NAMESPACE::basic_ostringstream;
using __STL_NEW_IO_NAMESPACE::basic_stringstream;
using __STL_NEW_IO_NAMESPACE::istringstream;
using __STL_NEW_IO_NAMESPACE::ostringstream;
using __STL_NEW_IO_NAMESPACE::stringstream;

#ifndef __STL_NO_WIDE_STREAMS
using __STL_NEW_IO_NAMESPACE::wstringbuf;
using __STL_NEW_IO_NAMESPACE::wistringstream;
using __STL_NEW_IO_NAMESPACE::wostringstream;
using __STL_NEW_IO_NAMESPACE::wstringstream;
#endif
