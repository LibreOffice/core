#include <stdio.h>


#if defined(__hpux) 
aaaa
#endif

int
main()
{
 printf("%d\n",__cplusplus);
}
