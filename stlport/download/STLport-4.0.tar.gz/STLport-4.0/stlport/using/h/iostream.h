using __STL_OLD_IO_NAMESPACE::istream;
using __STL_OLD_IO_NAMESPACE::ostream;
using __STL_OLD_IO_NAMESPACE::cin;
using __STL_OLD_IO_NAMESPACE::cout;
using __STL_OLD_IO_NAMESPACE::cerr;
using __STL_OLD_IO_NAMESPACE::clog;
using __STL_OLD_IO_NAMESPACE::endl;
using __STL_OLD_IO_NAMESPACE::ends;

using __STL_OLD_IO_NAMESPACE::ios;
using __STL_OLD_IO_NAMESPACE::flush;

// using __STL_OLD_IO_NAMESPACE::ws;
