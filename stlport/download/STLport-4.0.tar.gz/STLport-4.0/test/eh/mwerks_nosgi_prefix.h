//mwerks_nosgi_prefix.h
#define __STL_NO_SGI_IOSTREAMS 1
#define __STL_NO_FORCE_INSTANTIATE 1 // for debugging
#define EH_VECTOR_OPERATOR_NEW 1
#define NDEBUG 1
