using _STLP_NEW_IO_NAMESPACE::basic_ostream;
using _STLP_NEW_IO_NAMESPACE::ostream;

# ifndef _STLP_NO_WIDE_STREAMS
using _STLP_NEW_IO_NAMESPACE::wostream;
# endif

using _STLP_NEW_IO_NAMESPACE::endl;
using _STLP_NEW_IO_NAMESPACE::ends;
using _STLP_NEW_IO_NAMESPACE::flush;
