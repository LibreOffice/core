#ifdef _STLP_BROKEN_USING_DIRECTIVE
using namespace _STLP_STD;
#else
using _STLP_NEW_IO_NAMESPACE::basic_filebuf;
using _STLP_NEW_IO_NAMESPACE::filebuf;
using _STLP_NEW_IO_NAMESPACE::basic_ifstream;
using _STLP_NEW_IO_NAMESPACE::basic_ofstream;
using _STLP_NEW_IO_NAMESPACE::ifstream;
using _STLP_NEW_IO_NAMESPACE::ofstream;
using _STLP_NEW_IO_NAMESPACE::basic_fstream;
using _STLP_NEW_IO_NAMESPACE::fstream;

# ifndef _STLP_NO_WIDE_STREAMS
using _STLP_NEW_IO_NAMESPACE::wofstream;
using _STLP_NEW_IO_NAMESPACE::wfilebuf;
using _STLP_NEW_IO_NAMESPACE::wifstream;
using _STLP_NEW_IO_NAMESPACE::wfstream;
# endif
#endif
