To generate the API documentation for the mod_jk library, simply invoke
  make apidocs
from the mod_jk Library root source path. (jakarta-tomcat-connectors/jk/native)
