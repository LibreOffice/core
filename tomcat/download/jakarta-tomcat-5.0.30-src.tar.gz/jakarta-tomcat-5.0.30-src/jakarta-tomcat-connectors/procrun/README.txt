
Placeholder for procrun binaries used for Tomcat 5.x

Rename binaries to reflect default service name:
  prunsrv.exe -> tomcat5.exe
  prunmgr.exe -> tomcat5w.exe

Documentation for the commons-daemon project, which is
where procrun comes from, is at
http://jakarta.apache.org/commons/daemon.  That site
has links to the CVS repository and the source code for
the project.
