module.exports = 'wtf';
